Traveled : 1 Yard
Direction: X Acceleration (view image for direction)

device was on a 18"x10" wooden board. Pushed device slowly across the floor with one end butt against the
wall. friction and vibration will give readings in the y and z axis. 


